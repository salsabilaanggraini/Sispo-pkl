<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="chat-container">
        <h2>Konsultasi chat</h2>
        <div class="chat-box" id="chat-box"></div>
        <input type="text" id="chatinput" class="chat-input" placeholder="Tulis pesan..">
        <button onclick="sendMessage()">Kirim</button>
    </div>

    <script>
        function sendMessage(){
            const chatinput = Document.getElementByid('chatInput');
            const chatBox = Document.getElementByid('chatBox');
            const message = chatInput.value.trim();

            if(message){
                const userMessage = Document.createElement('div');
                userMessage.className = 'message admin';
                userMessage.innerText = message;
                chatBox.appendChild(userMessage);
                const adminMessage = document.createElement('div');
                adminMessage.className = 'message admin';
                adminMessage.innerText = 'Admin: Terima kasih, pesan Andatelah diterima.';
                chatBox.appendChild(adminMessage);
                chatBox.scrollTop = chatBox.scrollHeight;
                chatInput.value = '';
            }
        }
    </script>
</body>
</html>