<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <nav>
        <a href="CRUDD/home.php" target="contentFrame">Home</a>
        <a href="CRUDD/jurnal.php" target="contentFrame">Jurnal</a>
        <a href="CRUDD/absen.php" target="contentFrame">Absen</a>
        <a href="CRUDD/konsultasi.php" target="contentFrame">konsultasi</a>
    </nav>
</body>
</html>